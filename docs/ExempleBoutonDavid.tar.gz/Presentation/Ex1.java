// Exemple 1 :
//
import javax.swing.*;
import java.awt.*;
public class Ex1 {
  public static void main(String[] args) {

    // Création de deux boutons :
    JButton ok = new JButton("Bouton 1");
    JButton cancel = new JButton("Bouton 2");

    // Affectation de ces deux boutons à un JPanel :
    JPanel buttonPanel = new JPanel( );
    buttonPanel.add(ok);
    buttonPanel.add(cancel);

    // Création d'un message à afficher :
    JLabel msg = new JLabel("Clique sur un bouton", JLabel.CENTER);

    // Création d'une fenêtre pour mettre tout ça :
    JFrame f = new JFrame("Exemple 1");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JRootPane root = f.getRootPane( );
    root.setDefaultButton(ok);

    // Placements des objets (types points cardianaux) 
    Container content = f.getContentPane( );
    content.add(msg, BorderLayout.CENTER);
    content.add(buttonPanel, BorderLayout.SOUTH);
    f.setSize(400,100);
    f.setVisible(true);
  }
}