// Exemple 7 :
//
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Ex7 {
    public static void main(String[] args) {

    // Création de deux boutons :
    final JRadioButton b1 = new JRadioButton("JRadioButton 1");
    final JRadioButton b2 = new JRadioButton("JRadioButton 2");

    // Affectation de ces deux boutons à un JPanel :
    JPanel buttonPanel = new JPanel( );
    buttonPanel.add(b1);
    buttonPanel.add(b2);

    // Groupement des Radiobutton
    final ButtonGroup group = new ButtonGroup( );
    group.add(b1);
    group.add(b2);

    // Création d'un message à afficher 
    // ATTENTION : doit être déclaré final!
    final JLabel msg = new JLabel("aucun(e) checkbox sélectionné!", JLabel.CENTER);

    // Création d'une fenêtre pour mettre tout ça :
    JFrame f = new JFrame("Exemple 7");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 

    // Placements des objets (types points cardianaux) 
    Container content = f.getContentPane( );
    content.add(msg, BorderLayout.CENTER);
    content.add(buttonPanel, BorderLayout.SOUTH);
    f.setSize(400,100);
    f.setVisible(true);

    // Création d'auditeurs :
    b1.addActionListener(new ActionListener( ) {
	    public void actionPerformed(ActionEvent e) {
		if ( (b1.isSelected())&&(b2.isSelected()) )
		    msg.setText("Radiobuton 1 et 2 sélectionnés!");
		else {
		    if (b1.isSelected())
			msg.setText("Radiobuton 1 sélectionné!");
		    else if (b2.isSelected())
			msg.setText("Radiobutton 2 sélectionné!");
		    else msg.setText("Aucun radiobutton sélectionné!");
		}
		
	    }
	});
    b2.addActionListener(new ActionListener( ) {
	    public void actionPerformed(ActionEvent e) {
		if ( (b1.isSelected())&&(b2.isSelected()) )
		    msg.setText("Radiobuton 1 et 2 sélectionnés!");
		else {
		    if (b1.isSelected())
			msg.setText("Radiobuton 1 sélectionné!");
		    else if (b2.isSelected())
			msg.setText("Radiobutton 2 sélectionné!");
		    else msg.setText("Aucun radiobutton sélectionné!");
		}
		
	    }
	});
  }
}