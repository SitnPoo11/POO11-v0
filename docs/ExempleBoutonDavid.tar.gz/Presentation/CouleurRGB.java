import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CouleurRGB extends JPanel {

    int rouge, vert, bleu;
    JTextField texteR = new JTextField("0",3),
	texteG = new JTextField("0",3),
        texteB = new JTextField("0",3);
    JScrollBar jsbR = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256),
	jsbG = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256),
        jsbB = new JScrollBar(JScrollBar.HORIZONTAL, 0, 1, 0, 256);
    JLabel labelR = new JLabel("Rouge"),
	labelG = new JLabel("Vert"),
	labelB = new JLabel("Bleu");

    JPanel panneauRGB = new JPanel();
    JPanel panneauR = new JPanel();
    JPanel panneauG = new JPanel();
    JPanel panneauB = new JPanel();
    
    CouleurListener auditeur = new CouleurListener();
    CouleurNumListener auditeurNum = new CouleurNumListener();

    public CouleurRGB(int r, int v, int b){
	rouge = r;
	vert = v;
	bleu = b;
	
        jsbR.addAdjustmentListener(auditeur);
	texteR.addActionListener(auditeurNum);
        jsbG.addAdjustmentListener(auditeur);
	texteG.addActionListener(auditeurNum);	
        jsbB.addAdjustmentListener(auditeur);
	texteB.addActionListener(auditeurNum);		
       
	setLayout(new GridLayout(4,1,5,5));
	this.add(panneauRGB);
	panneauR.setLayout(new GridLayout(1,3));
	labelR.setForeground(new Color(255,0,0)); 
	panneauR.add(labelR);
	panneauR.add(jsbR);
	panneauR.add(texteR);
	this.add(panneauR);
	panneauG.setLayout(new GridLayout(1,3));
	labelG.setForeground(new Color(0,255,0)); 
	panneauG.add(labelG);
	panneauG.add(jsbG);
	panneauG.add(texteG);
	this.add(panneauG);
	panneauB.setLayout(new GridLayout(1,3));
	labelB.setForeground(new Color(0,0,255)); 
	panneauB.add(labelB);
	panneauB.add(jsbB);
	panneauB.add(texteB);
	this.add(panneauB);
	panneauRGB.setBackground(new Color(rouge, vert, bleu));

    }
    
    public CouleurRGB(){ 
	this(0,0,0);
    }

    public void changerRouge(int r){
	if (r<0) r=0;
	if (r>255) r=255;
	rouge = r;
	jsbR.setValue(r);
	texteR.setText(String.valueOf(r));
	panneauRGB.setBackground(new Color(rouge, vert, bleu));
    }

    public void changerVert(int v){
	if (v<0) v=0;
	if (v>255) v=255;
	vert = v;
	jsbG.setValue(v);
	texteG.setText(String.valueOf(v));
	panneauRGB.setBackground(new Color(rouge, vert, bleu));	
    }

    public void changerBleu(int b){
	if (b<0) b=0;
	if (b>255) b=255;
	bleu = b;
	jsbB.setValue(b);
	texteB.setText(String.valueOf(b));
	panneauRGB.setBackground(new Color(rouge, vert, bleu));
    }

    class CouleurListener implements AdjustmentListener{
	public void adjustmentValueChanged(AdjustmentEvent a){
	    //System.out.println(a.getValue());
	    if(a.getSource()==jsbR){changerRouge(a.getValue());}
	    else if(a.getSource()==jsbG){changerVert(a.getValue());}
	    else {changerBleu(a.getValue());}
	}
   }

    class CouleurNumListener implements ActionListener{
	public void actionPerformed(ActionEvent a){
	    try {
		//System.out.println(a.getActionCommand());
		int i = Integer.parseInt(a.getActionCommand());
		if(a.getSource()==texteR){changerRouge(i);}
		else if(a.getSource()==texteG){changerVert(i);}
		else {changerBleu(i);} 
	    }
	    catch (NumberFormatException e){}
	}
    }
    public static void main(String [] args){
	JFrame f = new JFrame("Couleur RGB");
	f.setContentPane(new CouleurRGB());
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.pack();
	f.setVisible(true); 
	//f.setResizable(false);
	f.setSize(500, 300);
    }
}