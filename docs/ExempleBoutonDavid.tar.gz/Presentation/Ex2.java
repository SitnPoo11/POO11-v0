// Exemple 2 :
//
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Ex2 {
  public static void main(String[] args) {

    // Création de deux boutons :
    JButton b1 = new JButton("Bouton 1");
    JButton b2 = new JButton("Bouton 2");

    // Affectation de ces deux boutons à un JPanel :
    JPanel buttonPanel = new JPanel( );
    buttonPanel.add(b1);
    buttonPanel.add(b2);

    // Création d'un message à afficher 
    // ATTENTION : doit être déclaré final!
    final JLabel msg = new JLabel("Clique sur un bouton", JLabel.CENTER);

    // Création d'une fenêtre pour mettre tout ça :
    JFrame f = new JFrame("Exemple 2");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JRootPane root = f.getRootPane( );
    root.setDefaultButton(b1);

    // Placements des objets (types points cardianaux) 
    Container content = f.getContentPane( );
    content.add(msg, BorderLayout.CENTER);
    content.add(buttonPanel, BorderLayout.SOUTH);
    f.setSize(400,100);
    f.setVisible(true);

    // Création d'auditeurs :
    b1.addActionListener(new ActionListener( ) {
      public void actionPerformed(ActionEvent e) {
	  msg.setText("Bouton 1 a été cliqué!");
      }
    });
    b2.addActionListener(new ActionListener( ) {
      public void actionPerformed(ActionEvent e) {
	  msg.setText("Bouton 2 a été cliqué!");
      }
    });
  }
}